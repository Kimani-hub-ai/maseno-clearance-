<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Department;
use App\Models\DepartmentOfficer;
use App\Enums\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AdminOfficerController extends Controller
{
    /**
     * Display the Admin Dashboard with the dynamic dropdown collection.
     */
    public function index()
    {
        // Grab all active checkpoints from your MariaDB database
        $departments = Department::where('is_active', true)->orderBy('name', 'asc')->get();

        // Pass them directly down into your dashboards/admin view
        return view('dashboards.admin', compact('departments'));
    }

    /**
     * Store a newly created officer profile in the database.
     */
    public function store(Request $request)
    {
        // 1. Strictly validate the incoming form data
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email',
            'department_id' => 'required|exists:departments,id'
        ]);

        // 2. Generate a clean, temporary password string
        $temporaryPassword = 'Maseno!' . Str::random(6);

        // 3. Process the nested inserts safely using a DB Transaction wrapper
        DB::transaction(function() use ($validated, $temporaryPassword) {
            
            // Step A: Create the base authenticated User account row
            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($temporaryPassword),
                'role' => UserRole::Officer, // Maps to your enum rules
                'is_active' => true,
            ]);

            // Step B: Spin up the linkage row inside your department_officers profile table
            DepartmentOfficer::create([
                'user_id' => $user->id,
                'department_id' => $validated['department_id'],
            ]);
        });

        // 4. Send back a success notice displaying the account's password details
        return redirect()->back()->with(
            'success', 
            "Account provisioned successfully! Give the operator their temporary credentials: Email: {$validated['email']} | Password: {$temporaryPassword}"
        );
    }
}