<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use App\Models\DepartmentClearance;
use App\Services\ClearanceService;
use App\Enums\DepartmentClearanceStatus;
use Illuminate\Http\Request;

class DepartmentClearanceController extends Controller
{
    /**
     * Inject your core clearance service engine.
     */
    public function __construct(
        protected ClearanceService $clearanceService
    ) {}

    /**
     * 1. THE ADMIN PAGE QUEUE
     * Displays all pending student clearance requests for the logged-in officer's department.
     */
   public function index(Request $request)
    {
        $officer = $request->user();
        
        // Correctly target Developer A's profile relation string mapping
        $departmentId = $officer->departmentOfficer?->department_id; 

        if (!$departmentId) {
            return redirect()->back()->with('error', 'Account configuration missing: No department assigned.');
        }

        // Fetch all student line items waiting on this department that are Pending
        $pendingClearances = DepartmentClearance::with(['clearanceApplication.student', 'department'])
            ->where('department_id', $departmentId)
            ->where('status', \App\Enums\DepartmentClearanceStatus::Pending) // Ensure it checks enum
            ->orderBy('created_at', 'asc')
            ->paginate(15);

        return view('dashboards.department', compact('pendingClearances','departmentId'));
    }

    /**
     * 2. THE APPROVAL SEQUENCE
     * Processes the Approve/Reject form submissions from the dashboard buttons.
     */
    public function review(Request $request, DepartmentClearance $checkpoint)
    {
        // Validate the form payload fields
        $validated = $request->validate([
            'action' => 'required|in:approve,reject',
            'remarks' => 'nullable|string|max:500',
        ]);

        // Hand execution over to your service layer engine
        $this->clearanceService->reviewDepartmentCheckpoint(
            $checkpoint,
            $validated['action'],
            $request->user(),
            $validated['remarks'] ?? null
        );

        // Send them right back to the list with a success message banner
        return redirect()->back()->with('success', 'Student clearance record updated successfully!');
    }
}